$(document).ready(function(){
    $("#r1").draggable();
    $("#r2").droppable({
        accept: "#r1",
        drop: function(event, ui){
            $(this).addClass("MyCls").find("p").html("done...");
        }
    })
})