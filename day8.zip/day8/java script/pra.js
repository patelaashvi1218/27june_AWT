function internalalertjs()
        {
            alert('hello guys');
        }
        function confirmjs(){
            confirm('confirm message');
        }
        function promptjs(){
            prompt('enter name');
        }
        console.log('hello');
        function vv(){
       document.body.style.backgroundColor="yellow";}
       function dd(){
       document.getElementById('d1').style.backgroundColor=prompt('enter your color');}
       function dd1(){
        document.getElementById('d2').style.backgroundColor="pink";}
        function dd2(){
            document.getElementById('d3').style.backgroundColor="pink";}
        function ab(){
            document.body.style.backgroundColor=document.getElementById('d4').value;
        }    
        function ab1(){
            document.getElementById('d6').style.backgroundcolor=document.getElementById('d5').value;
        }
        function ab3(){
            var abc=prompt('enter the value');
            document.getElementById('d7').innerHTML=abc;
        }   
        function df(){
            document.getElementById('d6').style.backgroundColor=document.getElementById('d8').value;
        }
        function aaa1(){
            var abcd=prompt('enter the value');
            document.getElementById('d9').innerHTML=abcd;
            var abcde=prompt('enter the value');
            document.getElementById('d10').innerHTML=abcde;
        }