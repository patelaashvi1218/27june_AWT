function image()
{
    document.getElementById("box1").src="../img/place.jpg";
}
