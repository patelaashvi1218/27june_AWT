$(document).ready(function(){
    $("#id1").click(function(){
        alert("Hello");
        $("#note").hide(5000);
    })
})
$(document).ready(function(){
    $("#id2").click(function(){
        alert("Hello");
        $("#note").show(5000);
    })
})
$(document).ready(function(){
    $("#id3").click(function(){
        alert("Hello");
        $("#note").width(200);
        $("#note").height(200);
    })
})
$(document).ready(function(){
    $("#id4").click(function(){
        alert("Hello");
        $("#note").width(50);
        $("#note").height(50);
    })
})
$(document).ready(function(){
$("#id3").click(function(){
    alert("Hello");
    var MDH=parseInt($("#note").css("height"));
    if(MDH<=150)
    {
        MDH+=10;
        $("#note").css("height",MDH);
        $("#note").css("width",MDH);
    }
    else{
        alert("More than 150px is not possible.");
    }
})
});
$(document).ready(function(){
    $("#id4").click(function(){
        alert("Hello");
        var MDH=parseInt($("#meera").css("height"));
        if(MDH>=20)
        {
            MDH-=10;
            $("#note").css("height",MDH);
            $("#note").css("width",MDH);
        }
        else{
            alert("less than 20px is not possible.");
        }
    })
    });
    
$("#id2").attr("disabled",true);
$("#id1").click(function(){
    if(confirm("Are you sure..??"))
    {
        $("#note").hide(3000);
        $(this).attr("disabled",true);
        $("#id2").attr("disabled",false);
    }
})
$("#id2").click(function(){
    if(confirm("Are you sure..??"))
    {
        $("#note").show(3000);
        $(this).attr("disabled",true);
        $("#id2").attr("disabled",false);
    }
})
        
        