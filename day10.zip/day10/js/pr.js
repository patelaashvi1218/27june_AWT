function size(){
   document.getElementById("btn2").style.fontSize="100px"
}
function change() {
    document.getElementById("btn1").style.fontFamily = "Impact,Charcoal,sans-serif";
    
}
function hide(){
    document.getElementById("btn3").style.display = "none";
}